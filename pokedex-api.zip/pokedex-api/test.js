import { leerPokemon, crearPokemon, borrarPokemon, editarPokemon } from "./db.js";

// Prueba de crearPokemon 

async function probarCrearPokemon() {
    const nuevoPokemon = { nombre: "Bulbasur", tipo: "Planta" };
    try {
        const id = await crearPokemon(nuevoPokemon);
        console.log("Pokémon creado con ID:", id);
    } catch (error) {
        console.error("Error al crear el Pokémon:", error);
    }
}

// Prueba de leerPokemon
async function probarLeerPokemon() {
    try {
        const pokemons = await leerPokemon();
        console.log("Lista de Pokémon:", pokemons);
    } catch (error) {
        console.error("Error al leer los Pokémon:", error);
    }
}

//Prueba borrarPokemon

async function probarBorrarPokemon() {
    const id = "676d18f23d7036b240d4a318"; // Reemplaza con un ID válido en tu base de datos
    try {
        const resultado = await borrarPokemon(id); // Llamamos a la función borrarPokemon
        console.log("Resultado de borrarPokemon:", resultado);
    } catch (error) {
        console.error("Error al borrar el Pokémon:", error);
    }
}

// Ejecutamos la prueba
//probarBorrarPokemon();


//Prueba editarPokemon 

async function probarEditarPokemon() {
    const id = "676d194f6046e0fdb5407978"; // Reemplaza con un ID válido
    const nuevosDatos = { nombre: "Raichu", tipo: "Eléctrico" }; // Nuevos valores
    try {
        const resultado = await editarPokemon(id, nuevosDatos);
        console.log(resultado);
    } catch (error) {
        console.error("Error al editar el Pokémon:", error);
    }
}



// Ejecutar las pruebas
async function ejecutarPruebas() {
    console.log("Probando crearPokemon...");
    await probarCrearPokemon();

    console.log("Probando leerPokemon...");
    await probarLeerPokemon();

    console.log("Probando borrarPokemon...");
    await probarBorrarPokemon();

    console.log("Probando editarPokemon...");
    await probarEditarPokemon();
}

ejecutarPruebas();

